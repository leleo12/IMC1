# Projeto1-IMC

Neste projeto, a partir do nome, da idade e da altura do usuário, calcula-se o IMC e avalia-se em qual faixa de peso ele se encontra. A solução pode ser utilizada por médicos, nutricionistas e educadores físicos, por exemplo.

<a href="https://alexandrerodrigues2311.github.io/Projeto1-IMC/"><img src=".\imc.png" width="250px"></a>

